const { createApp, ref, computed, onMounted, onUnmounted, watch, nextTick } = Vue;

const API_BASE = '/api';

const app = createApp({
    setup() {
        // --- State ---
        const currentView = ref('dashboard');
        const sidebarOpen = ref(false);
        const theme = ref(localStorage.getItem('theme') || 'dark');
        
        const expenses = ref([]);
        const categories = ref([]);
        const analytics = ref({
            summary: { grand_total: 0, average: 0, highest: 0, lowest: 0, count: 0, highest_expense: null, lowest_expense: null, current_month_total: 0 },
            category_breakdown: [],
            monthly_breakdown: []
        });
        
        // User Settings
        const settings = ref({
            currency: localStorage.getItem('currency') || '₹',
            userName: localStorage.getItem('userName') || 'Prem',
            monthlyBudget: parseFloat(localStorage.getItem('monthlyBudget')) || 15000
        });

        // Modals
        const showQuickAddModal = ref(false);
        const showShortcutsModal = ref(false);
        const expenseToDelete = ref(null);

        const loading = ref({
            global: true,
            form: false,
            quickForm: false
        });
        
        const error = ref(null);
        const liveAnnouncement = ref('');
        const notification = ref({
            show: false,
            message: '',
            type: 'success'
        });

        // --- Category Icons Mapping ---
        const categoryIcons = {
            'Food': 'ph-bold ph-fork-knife',
            'Transport': 'ph-bold ph-car',
            'Entertainment': 'ph-bold ph-film-strip',
            'Shopping': 'ph-bold ph-shopping-bag-open',
            'Education': 'ph-bold ph-graduation-cap',
            'Bills': 'ph-bold ph-lightning',
            'Health': 'ph-bold ph-first-aid-kit',
            'Other': 'ph-bold ph-dots-three-circle'
        };

        // --- Date helpers ---
        // BUG FIX: Date.prototype.toISOString() converts to UTC before formatting.
        // For timezones ahead of UTC (e.g. IST, UTC+5:30), calling it in the early
        // hours of the morning (00:00–05:30 local time) rolls the date back to the
        // PREVIOUS day. toLocalISODate() builds the YYYY-MM-DD string from the
        // browser's local date fields instead, so the date shown/submitted always
        // matches the date the user actually sees on their device.
        const toLocalISODate = (d) => {
            const year = d.getFullYear();
            const month = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        };

        // --- Form States ---
        const today = toLocalISODate(new Date());
        const initialFormState = {
            amount: '',
            date: today,
            category: 'Food',
            description: ''
        };
        const form = ref({ ...initialFormState });
        const quickForm = ref({ ...initialFormState });

        // --- Filter State (Transactions) ---
        const filters = ref({
            search: '',
            category: '',
            sort: 'date_desc'
        });

        // --- Computed Properties ---
        const currentViewTitle = computed(() => {
            if (currentView.value === 'add') return 'Add Expense';
            return currentView.value.charAt(0).toUpperCase() + currentView.value.slice(1);
        });

        const timeGreeting = computed(() => {
            const hour = new Date().getHours();
            if (hour < 12) return 'Good Morning';
            if (hour < 17) return 'Good Afternoon';
            return 'Good Evening';
        });

        const currentDateFormatted = computed(() => {
            const options = { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' };
            return new Date().toLocaleDateString('en-US', options);
        });

        const currencySymbol = computed(() => settings.value.currency);

        const budgetSpentPercentage = computed(() => {
            if (!settings.value.monthlyBudget || settings.value.monthlyBudget <= 0) return 0;
            const pct = (analytics.value.summary.current_month_total / settings.value.monthlyBudget) * 100;
            return Math.min(Math.round(pct), 100);
        });

        const budgetRemaining = computed(() => {
            return Math.max(0, settings.value.monthlyBudget - analytics.value.summary.current_month_total);
        });

        const budgetStatusClass = computed(() => {
            const pct = (analytics.value.summary.current_month_total / settings.value.monthlyBudget) * 100;
            if (pct >= 100) return 'text-rose-500 bg-rose-500/10 border-rose-500/30';
            if (pct >= 80) return 'text-amber-500 bg-amber-500/10 border-amber-500/30';
            return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/30';
        });

        const budgetStatusText = computed(() => {
            const pct = (analytics.value.summary.current_month_total / settings.value.monthlyBudget) * 100;
            if (pct >= 100) return 'Budget Exceeded';
            if (pct >= 80) return 'Near Limit';
            return 'On Track';
        });

        const filteredExpenses = computed(() => {
            let result = [...expenses.value];
            
            if (filters.value.search) {
                const s = filters.value.search.toLowerCase();
                result = result.filter(e => 
                    (e.description && e.description.toLowerCase().includes(s)) ||
                    e.category.toLowerCase().includes(s)
                );
            }
            
            if (filters.value.category) {
                result = result.filter(e => e.category === filters.value.category);
            }
            
            result.sort((a, b) => {
                if (filters.value.sort === 'date_desc') {
                    if (a.date !== b.date) return new Date(b.date) - new Date(a.date);
                    return b.id - a.id;
                }
                if (filters.value.sort === 'date_asc') {
                    if (a.date !== b.date) return new Date(a.date) - new Date(b.date);
                    return a.id - b.id;
                }
                if (filters.value.sort === 'amount_desc') return b.amount - a.amount;
                if (filters.value.sort === 'amount_asc') return a.amount - b.amount;
                return 0;
            });
            
            return result;
        });

        const filteredExpensesTotal = computed(() => {
            return filteredExpenses.value.reduce((sum, exp) => sum + exp.amount, 0);
        });

        const activeFiltersCount = computed(() => {
            let count = 0;
            if (filters.value.search) count++;
            if (filters.value.category) count++;
            return count;
        });

        // --- Chart Instances ---
        let dashboardMonthlyChart = null;
        let dashboardCategoryChart = null;
        let analyticsCategoryChart = null;
        let analyticsMonthlyChart = null;

        // --- Helper Methods ---

        const announce = (msg) => {
            liveAnnouncement.value = msg;
            setTimeout(() => { liveAnnouncement.value = ''; }, 3000);
        };

        const applyTheme = () => {
            if (theme.value === 'dark') {
                document.documentElement.classList.add('dark');
            } else {
                document.documentElement.classList.remove('dark');
            }
            updateChartsTheme();
        };

        const toggleTheme = () => {
            theme.value = theme.value === 'light' ? 'dark' : 'light';
            localStorage.setItem('theme', theme.value);
            applyTheme();
            announce(`Theme changed to ${theme.value} mode`);
        };

        const setTheme = (newTheme) => {
            theme.value = newTheme;
            localStorage.setItem('theme', theme.value);
            applyTheme();
            announce(`Theme changed to ${newTheme} mode`);
        };

        const saveSettings = () => {
            localStorage.setItem('currency', settings.value.currency);
            localStorage.setItem('userName', settings.value.userName);
            localStorage.setItem('monthlyBudget', settings.value.monthlyBudget);
            showNotification('Preferences updated successfully!');
            announce('Preferences saved');
        };

        const navigate = (view) => {
            currentView.value = view;
            sidebarOpen.value = false;
            announce(`Navigated to ${view} page`);
            
            nextTick(() => {
                const mainEl = document.getElementById('main-content');
                if (mainEl) mainEl.focus();

                if (view === 'dashboard') {
                    initDashboardCharts();
                } else if (view === 'analytics') {
                    initAnalyticsCharts();
                }
            });
        };

        const showNotification = (message, type = 'success') => {
            notification.value = { show: true, message, type };
            announce(message);
            setTimeout(() => {
                if (notification.value.show && notification.value.message === message) {
                    notification.value.show = false;
                }
            }, 4000);
        };

        const formatCurrency = (value) => {
            if (value === undefined || value === null || isNaN(value)) return `${currencySymbol.value} 0.00`;
            const num = Number(value);
            return `${currencySymbol.value} ${num.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        };

        const formatDate = (dateStr) => {
            if (!dateStr) return '—';
            try {
                const [y, m, d] = dateStr.split('-');
                if (!y || !m || !d) return dateStr;
                const date = new Date(parseInt(y), parseInt(m) - 1, parseInt(d));
                return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
            } catch (e) {
                return dateStr;
            }
        };

        const formatMonth = (monthStr) => {
            if (!monthStr || monthStr === 'Unknown') return 'Unknown';
            try {
                const [year, month] = monthStr.split('-');
                if (!year || !month) return monthStr;
                const date = new Date(parseInt(year), parseInt(month) - 1, 1);
                return date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
            } catch (e) {
                return monthStr;
            }
        };

        const getCategoryPercentage = (amount) => {
            if (!analytics.value.summary.grand_total) return '0.0';
            return ((amount / analytics.value.summary.grand_total) * 100).toFixed(1);
        };

        const getCategoryBadgeColor = (category) => {
            const map = {
                'Food': 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/20',
                'Transport': 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20',
                'Entertainment': 'bg-purple-500/10 text-purple-600 dark:text-purple-400 border-purple-500/20',
                'Shopping': 'bg-pink-500/10 text-pink-600 dark:text-pink-400 border-pink-500/20',
                'Education': 'bg-teal-500/10 text-teal-600 dark:text-teal-400 border-teal-500/20',
                'Bills': 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20',
                'Health': 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',
                'Other': 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/20'
            };
            return map[category] || 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/20';
        };

        const getCategoryIcon = (category) => {
            return categoryIcons[category] || 'ph-bold ph-tag';
        };

        const setFormDate = (type, targetForm = 'form') => {
            const d = new Date();
            if (type === 'yesterday') {
                d.setDate(d.getDate() - 1);
            }
            const dateStr = toLocalISODate(d);
            if (targetForm === 'quick') {
                quickForm.value.date = dateStr;
            } else {
                form.value.date = dateStr;
            }
        };

        const resetForm = () => {
            form.value = { ...initialFormState, category: categories.value[0] || 'Food' };
        };

        const resetFilters = () => {
            filters.value = { search: '', category: '', sort: 'date_desc' };
            announce('Filters reset');
        };

        // Export Transactions as CSV File
        const exportCSV = () => {
            if (!expenses.value.length) {
                showNotification('No transactions available to export.', 'error');
                return;
            }
            
            const headers = ['ID', 'Date', 'Category', 'Amount', 'Description'];
            const rows = expenses.value.map(e => [
                e.id,
                `"${e.date}"`,
                `"${e.category}"`,
                e.amount,
                `"${(e.description || '').replace(/"/g, '""')}"`
            ]);
            
            const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.setAttribute('href', url);
            link.setAttribute('download', `Expense_Tracker_Export_${toLocalISODate(new Date())}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            showNotification('CSV exported successfully!');
        };

        // --- API Calls ---

        const fetchData = async () => {
            loading.value.global = true;
            error.value = null;
            
            try {
                const [expensesRes, analyticsRes, categoriesRes] = await Promise.all([
                    fetch(`${API_BASE}/expenses`),
                    fetch(`${API_BASE}/analytics`),
                    fetch(`${API_BASE}/categories`)
                ]);

                if (!expensesRes.ok || !analyticsRes.ok || !categoriesRes.ok) {
                    throw new Error('Failed to fetch data from backend.');
                }

                expenses.value = await expensesRes.json();
                analytics.value = await analyticsRes.json();
                categories.value = await categoriesRes.json();

                if (!form.value.category && categories.value.length > 0) {
                    form.value.category = categories.value[0];
                    quickForm.value.category = categories.value[0];
                }

                nextTick(() => {
                    if (currentView.value === 'dashboard') initDashboardCharts();
                    if (currentView.value === 'analytics') initAnalyticsCharts();
                });

            } catch (err) {
                error.value = 'Unable to connect to the backend server. Please verify python api.py is running.';
                console.error(err);
            } finally {
                loading.value.global = false;
            }
        };

        const submitExpense = async () => {
            if (!form.value.amount || Number(form.value.amount) <= 0) {
                showNotification('Please enter a valid positive amount.', 'error');
                return;
            }
            if (!form.value.category) {
                showNotification('Please select a category.', 'error');
                return;
            }

            loading.value.form = true;
            try {
                const payload = {
                    amount: parseFloat(form.value.amount),
                    category: form.value.category,
                    date: form.value.date,
                    description: form.value.description || ''
                };

                const res = await fetch(`${API_BASE}/expenses`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                if (!res.ok) {
                    const data = await res.json();
                    throw new Error(data.detail || 'Failed to save expense');
                }

                showNotification('Expense recorded successfully!');
                resetForm();
                await fetchData();
                navigate('dashboard');
                
            } catch (err) {
                showNotification(err.message, 'error');
            } finally {
                loading.value.form = false;
            }
        };

        const submitQuickExpense = async () => {
            if (!quickForm.value.amount || Number(quickForm.value.amount) <= 0) {
                showNotification('Please enter a valid positive amount.', 'error');
                return;
            }
            if (!quickForm.value.category) {
                showNotification('Please select a category.', 'error');
                return;
            }

            loading.value.quickForm = true;
            try {
                const payload = {
                    amount: parseFloat(quickForm.value.amount),
                    category: quickForm.value.category,
                    date: quickForm.value.date,
                    description: quickForm.value.description || ''
                };

                const res = await fetch(`${API_BASE}/expenses`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });

                if (!res.ok) {
                    const data = await res.json();
                    throw new Error(data.detail || 'Failed to save expense');
                }

                showNotification('Expense added via Quick Action!');
                quickForm.value = { ...initialFormState, category: categories.value[0] || 'Food' };
                showQuickAddModal.value = false;
                await fetchData();
                
            } catch (err) {
                showNotification(err.message, 'error');
            } finally {
                loading.value.quickForm = false;
            }
        };

        const confirmDelete = (expense) => {
            expenseToDelete.value = expense;
        };

        const executeDelete = async () => {
            if (!expenseToDelete.value) return;
            const id = expenseToDelete.value.id;
            
            try {
                const res = await fetch(`${API_BASE}/expenses/${id}`, { method: 'DELETE' });
                if (!res.ok) throw new Error('Failed to delete expense');
                
                showNotification('Expense deleted successfully.');
                expenseToDelete.value = null;
                await fetchData();
                
            } catch (err) {
                showNotification(err.message, 'error');
            }
        };

        // --- Chart Config & Rendering ---
        const abstractPalette = [
            '#6366f1', '#8b5cf6', '#ec4899', '#f43f5e', 
            '#10b981', '#06b6d4', '#f59e0b', '#64748b'
        ];

        const getChartOptions = (isPie = false) => {
            const isDark = theme.value === 'dark';
            const textColor = isDark ? '#94a3b8' : '#475569';
            const gridColor = isDark ? 'rgba(51, 65, 85, 0.4)' : 'rgba(226, 232, 240, 0.8)';

            let options = {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 800,
                    easing: 'easeOutQuart'
                },
                plugins: {
                    legend: {
                        labels: { 
                            color: textColor, 
                            font: { family: 'Plus Jakarta Sans', size: 12, weight: '600' },
                            usePointStyle: true,
                            padding: 16
                        },
                        position: isPie ? 'bottom' : 'top'
                    },
                    tooltip: {
                        backgroundColor: isDark ? 'rgba(15, 23, 42, 0.95)' : 'rgba(255, 255, 255, 0.95)',
                        titleColor: isDark ? '#f8fafc' : '#0f172a',
                        bodyColor: isDark ? '#cbd5e1' : '#334155',
                        borderColor: isDark ? 'rgba(99, 102, 241, 0.3)' : 'rgba(99, 102, 241, 0.2)',
                        borderWidth: 1.5,
                        padding: 12,
                        cornerRadius: 12,
                        boxPadding: 6,
                        usePointStyle: true,
                        callbacks: {
                            label: (context) => {
                                let label = context.dataset.label || '';
                                if (label) label += ': ';
                                const val = context.parsed.y !== undefined ? context.parsed.y : context.parsed;
                                label += formatCurrency(val);
                                return label;
                            }
                        }
                    }
                }
            };

            if (!isPie) {
                options.scales = {
                    x: { 
                        ticks: { color: textColor, font: { family: 'Plus Jakarta Sans', size: 11, weight: '500' } },
                        grid: { display: false }
                    },
                    y: { 
                        ticks: { 
                            color: textColor, 
                            font: { family: 'Plus Jakarta Sans', size: 11, weight: '500' },
                            callback: (val) => `${currencySymbol.value}${val}`
                        },
                        grid: { color: gridColor }
                    }
                };
            }

            return options;
        };

        const updateChartsTheme = () => {
            const charts = [dashboardMonthlyChart, dashboardCategoryChart, analyticsCategoryChart, analyticsMonthlyChart];
            charts.forEach(chart => {
                if (chart) {
                    const isPie = chart.config.type === 'doughnut';
                    chart.options = { ...chart.options, ...getChartOptions(isPie) };
                    chart.update();
                }
            });
        };

        const destroyCharts = (chartList) => {
            chartList.forEach(c => {
                if (c) {
                    try { c.destroy(); } catch (e) {}
                }
            });
        };

        const initDashboardCharts = () => {
            destroyCharts([dashboardMonthlyChart, dashboardCategoryChart]);
            
            // Monthly Chart (Chronological)
            const ctxMonthly = document.getElementById('dashboardMonthlyChart');
            if (ctxMonthly && analytics.value.monthly_breakdown && analytics.value.monthly_breakdown.length > 0) {
                dashboardMonthlyChart = new Chart(ctxMonthly, {
                    type: 'bar',
                    data: {
                        labels: analytics.value.monthly_breakdown.map(m => formatMonth(m.month)),
                        datasets: [{
                            label: 'Total Spent',
                            data: analytics.value.monthly_breakdown.map(m => m.total),
                            backgroundColor: '#6366f1',
                            hoverBackgroundColor: '#4f46e5',
                            borderRadius: 8,
                            barThickness: 28
                        }]
                    },
                    options: getChartOptions(false)
                });
            }

            // Category Chart (Distribution)
            const ctxCategory = document.getElementById('dashboardCategoryChart');
            if (ctxCategory && analytics.value.category_breakdown && analytics.value.category_breakdown.length > 0) {
                dashboardCategoryChart = new Chart(ctxCategory, {
                    type: 'doughnut',
                    data: {
                        labels: analytics.value.category_breakdown.map(c => c.category),
                        datasets: [{
                            data: analytics.value.category_breakdown.map(c => c.total),
                            backgroundColor: abstractPalette,
                            borderWidth: 2,
                            borderColor: theme.value === 'dark' ? '#0f172a' : '#ffffff',
                            hoverOffset: 8
                        }]
                    },
                    options: getChartOptions(true)
                });
            }
        };

        const initAnalyticsCharts = () => {
            destroyCharts([analyticsCategoryChart, analyticsMonthlyChart]);
            
            // Full Category Bar Chart
            const ctxCat = document.getElementById('analyticsCategoryBarChart');
            if (ctxCat && analytics.value.category_breakdown && analytics.value.category_breakdown.length > 0) {
                analyticsCategoryChart = new Chart(ctxCat, {
                    type: 'bar',
                    data: {
                        labels: analytics.value.category_breakdown.map(c => c.category),
                        datasets: [{
                            label: 'Amount Spent',
                            data: analytics.value.category_breakdown.map(c => c.total),
                            backgroundColor: abstractPalette,
                            borderRadius: 8,
                            barThickness: 32
                        }]
                    },
                    options: getChartOptions(false)
                });
            }

            // Full Monthly Line Chart
            const ctxLine = document.getElementById('analyticsMonthlyLineChart');
            if (ctxLine && analytics.value.monthly_breakdown && analytics.value.monthly_breakdown.length > 0) {
                analyticsMonthlyChart = new Chart(ctxLine, {
                    type: 'line',
                    data: {
                        labels: analytics.value.monthly_breakdown.map(m => formatMonth(m.month)),
                        datasets: [{
                            label: 'Monthly Trend',
                            data: analytics.value.monthly_breakdown.map(m => m.total),
                            borderColor: '#8b5cf6',
                            backgroundColor: 'rgba(139, 92, 246, 0.15)',
                            borderWidth: 3,
                            pointBackgroundColor: '#8b5cf6',
                            pointBorderColor: '#ffffff',
                            pointBorderWidth: 2,
                            pointRadius: 6,
                            pointHoverRadius: 9,
                            fill: true,
                            tension: 0.35
                        }]
                    },
                    options: getChartOptions(false)
                });
            }
        };

        // --- Keyboard Listener ---
        const handleGlobalKeyDown = (e) => {
            const isInput = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName);
            
            if (e.key === 'Escape') {
                if (showQuickAddModal.value) showQuickAddModal.value = false;
                if (showShortcutsModal.value) showShortcutsModal.value = false;
                if (expenseToDelete.value) expenseToDelete.value = null;
                if (sidebarOpen.value) sidebarOpen.value = false;
            }

            if (!isInput) {
                if (e.key === '/' || (e.ctrlKey && e.key === 'k')) {
                    e.preventDefault();
                    navigate('transactions');
                    nextTick(() => {
                        const searchInput = document.getElementById('searchInput');
                        if (searchInput) searchInput.focus();
                    });
                }
                if (e.key === '?' || (e.shiftKey && e.key === '?')) {
                    e.preventDefault();
                    showShortcutsModal.value = !showShortcutsModal.value;
                }
                if ((e.ctrlKey && e.shiftKey && e.key === 'A') || (e.altKey && e.key === 'n')) {
                    e.preventDefault();
                    showQuickAddModal.value = true;
                }
            }
        };

        // --- Lifecycle ---
        onMounted(() => {
            applyTheme();
            fetchData();
            window.addEventListener('keydown', handleGlobalKeyDown);
        });

        onUnmounted(() => {
            window.removeEventListener('keydown', handleGlobalKeyDown);
        });

        watch(sidebarOpen, () => {
            setTimeout(() => {
                const charts = [dashboardMonthlyChart, dashboardCategoryChart, analyticsCategoryChart, analyticsMonthlyChart];
                charts.forEach(c => c && c.resize());
            }, 300);
        });

        return {
            currentView, sidebarOpen, theme, expenses, categories, analytics, settings, loading, error, notification, liveAnnouncement,
            form, quickForm, filters, showQuickAddModal, showShortcutsModal, expenseToDelete, categoryIcons,
            currentViewTitle, timeGreeting, currentDateFormatted, currencySymbol, budgetSpentPercentage, budgetRemaining,
            budgetStatusClass, budgetStatusText, filteredExpenses, filteredExpensesTotal, activeFiltersCount,
            toggleTheme, setTheme, saveSettings, navigate, showNotification, formatCurrency, formatDate, formatMonth,
            getCategoryPercentage, getCategoryBadgeColor, getCategoryIcon, setFormDate, resetForm, resetFilters, exportCSV, fetchData, submitExpense,
            submitQuickExpense, confirmDelete, executeDelete
        };
    }
});

app.mount('#app');
