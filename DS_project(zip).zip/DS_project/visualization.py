"""
visualization.py
----------------
Chart generation for the Personal Expense Tracker using Matplotlib.

Provides:
  - Pie chart: spending by category
  - Bar chart: monthly spending trend
  - Horizontal bar chart: top expenses
  - Terminal ASCII chart (fallback / quick view)

Charts are saved as PNG images in the project folder AND displayed on screen.
"""

import os
import sys
from collections import defaultdict
from datetime import datetime

# ---------------------------------------------------------------------------
# Matplotlib import (required by assignment)
# ---------------------------------------------------------------------------
try:
    import matplotlib
    matplotlib.use("Agg")          # Non-interactive backend — works everywhere,
                                   # saves to file without needing a display
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

from expense_manager import DATE_FORMAT

# Where chart images are saved
CHARTS_DIR = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------------------
# Public chart functions
# ---------------------------------------------------------------------------

def show_category_pie_chart(expenses):
    """
    Generate and save a pie chart of spending by category using Matplotlib.
    Also prints the filename of the saved chart.

    Args:
        expenses (list): List of expense dicts.
    """
    if not expenses:
        print("\n  No data available to generate a chart.\n")
        return

    if not MATPLOTLIB_AVAILABLE:
        print("\n  [Warning] matplotlib is not installed. Run: pip install matplotlib\n")
        _ascii_bar_chart(expenses)
        return

    # Aggregate by category
    cat_totals = defaultdict(float)
    for exp in expenses:
        cat_totals[exp["category"]] += exp["amount"]

    labels = list(cat_totals.keys())
    values = [cat_totals[k] for k in labels]

    fig, ax = plt.subplots(figsize=(8, 6))
    wedges, texts, autotexts = ax.pie(
        values,
        labels=labels,
        autopct="%1.1f%%",
        startangle=140,
        pctdistance=0.82,
    )

    # Style
    for text in texts:
        text.set_fontsize(10)
    for at in autotexts:
        at.set_fontsize(9)
        at.set_color("white")

    ax.set_title("Spending by Category", fontsize=14, fontweight="bold", pad=20)

    grand_total = sum(values)
    ax.text(
        0, -1.35,
        f"Total: Rs. {grand_total:,.2f}  |  {len(expenses)} expense(s)",
        ha="center", fontsize=10, color="gray"
    )

    fig.tight_layout()
    output_path = os.path.join(CHARTS_DIR, "chart_category_pie.png")
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)

    print(f"\n  [OK] Pie chart saved to: {output_path}\n")


def show_monthly_bar_chart(expenses):
    """
    Generate and save a bar chart showing monthly spending trend.

    Args:
        expenses (list): List of expense dicts.
    """
    if not expenses:
        print("\n  No data available to generate a chart.\n")
        return

    if not MATPLOTLIB_AVAILABLE:
        print("\n  [Warning] matplotlib is not installed. Run: pip install matplotlib\n")
        return

    monthly_totals = defaultdict(float)
    for exp in expenses:
        try:
            dt        = datetime.strptime(exp["date"], DATE_FORMAT)
            month_key = dt.strftime("%Y-%m")
        except ValueError:
            month_key = "Unknown"
        monthly_totals[month_key] += exp["amount"]

    # Sort months chronologically
    sorted_months = sorted(monthly_totals.items())
    months = [m[0] for m in sorted_months]
    totals = [m[1] for m in sorted_months]

    fig, ax = plt.subplots(figsize=(max(6, len(months) * 1.4), 5))
    bars = ax.bar(months, totals, color="#4C72B0", edgecolor="white", linewidth=0.8)

    # Label each bar with its value
    for bar, val in zip(bars, totals):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + max(totals) * 0.01,
            f"Rs.{val:,.0f}",
            ha="center", va="bottom", fontsize=9
        )

    ax.set_title("Monthly Spending Trend", fontsize=14, fontweight="bold")
    ax.set_xlabel("Month", fontsize=11)
    ax.set_ylabel("Total Spent (Rs.)", fontsize=11)
    ax.tick_params(axis="x", rotation=30)
    ax.yaxis.set_major_formatter(
        plt.FuncFormatter(lambda x, _: f"Rs.{x:,.0f}")
    )
    ax.grid(axis="y", linestyle="--", alpha=0.5)

    fig.tight_layout()
    output_path = os.path.join(CHARTS_DIR, "chart_monthly_bar.png")
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)

    print(f"\n  [OK] Monthly bar chart saved to: {output_path}\n")


def show_top_expenses_chart(expenses):
    """
    Generate and save a horizontal bar chart of the top 10 expenses.

    Args:
        expenses (list): List of expense dicts.
    """
    if not expenses:
        print("\n  No data available to generate a chart.\n")
        return

    if not MATPLOTLIB_AVAILABLE:
        print("\n  [Warning] matplotlib is not installed. Run: pip install matplotlib\n")
        return

    # Sort by amount and take top 10
    sorted_exp = sorted(expenses, key=lambda e: e["amount"], reverse=True)[:10]

    labels = [
        f"#{e['id']} {e['category']} ({e['date']})" for e in sorted_exp
    ]
    values = [e["amount"] for e in sorted_exp]

    fig, ax = plt.subplots(figsize=(9, max(4, len(sorted_exp) * 0.6)))
    bars = ax.barh(labels[::-1], values[::-1], color="#DD8452", edgecolor="white")

    for bar, val in zip(bars, values[::-1]):
        ax.text(
            bar.get_width() + max(values) * 0.01,
            bar.get_y() + bar.get_height() / 2,
            f"Rs.{val:,.2f}",
            va="center", fontsize=9
        )

    ax.set_title("Top Expenses", fontsize=14, fontweight="bold")
    ax.set_xlabel("Amount (Rs.)", fontsize=11)
    ax.xaxis.set_major_formatter(
        plt.FuncFormatter(lambda x, _: f"Rs.{x:,.0f}")
    )
    ax.grid(axis="x", linestyle="--", alpha=0.5)

    fig.tight_layout()
    output_path = os.path.join(CHARTS_DIR, "chart_top_expenses.png")
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)

    print(f"\n  [OK] Top expenses chart saved to: {output_path}\n")


def generate_all_charts(expenses):
    """
    Convenience function: generate all three charts at once.

    Args:
        expenses (list): List of expense dicts.
    """
    print("\n--- Generating All Charts ---")
    show_category_pie_chart(expenses)
    show_monthly_bar_chart(expenses)
    show_top_expenses_chart(expenses)
    print("  All charts have been saved as PNG files in the project folder.\n")


# ---------------------------------------------------------------------------
# ASCII fallback chart (always works, no dependencies)
# ---------------------------------------------------------------------------

BAR_MAX_WIDTH = 38


def show_category_chart(expenses):
    """
    Display a quick horizontal ASCII bar chart grouped by category.
    This is a terminal-friendly quick view; use generate_all_charts() for
    full matplotlib PNG output.

    Args:
        expenses (list): List of expense dicts.
    """
    print("\n--- Spending by Category (Quick ASCII View) ---\n")

    if not expenses:
        print("  No data to display yet.\n")
        return

    cat_totals = defaultdict(float)
    for exp in expenses:
        cat_totals[exp["category"]] += exp["amount"]

    max_amount  = max(cat_totals.values())
    sorted_cats = sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)
    label_width = max(len(cat) for cat in cat_totals) + 2

    for cat, total in sorted_cats:
        filled = int((total / max_amount) * BAR_MAX_WIDTH)
        bar    = "#" * filled + "." * (BAR_MAX_WIDTH - filled)
        label  = f"{cat:<{label_width}}"
        print(f"  {label} |{bar}|  Rs.{total:,.2f}")

    print()

    print("  (Use option 6 to generate full Matplotlib PNG charts)\n")
