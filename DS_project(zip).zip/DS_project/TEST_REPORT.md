# TEST REPORT
## Personal Expense Tracker — Automated Test Results

**Test Runner**: `test_runner.py`  
**Date Executed**: 2026-09-25  
**Python Version**: 3.14.2  
**Total Test Cases**: 68  
**Passed**: 68 | **Failed**: 0  

---

## Section 1 — Amount Validation (9 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| AV-01 | Valid decimal amount | `"250.50"` | Returns `250.50` | `250.50` | PASS |
| AV-02 | Valid integer amount | `"1000"` | Returns `1000.0` | `1000.0` | PASS |
| AV-03 | Minimum valid amount | `"0.01"` | Returns `0.01` | `0.01` | PASS |
| AV-04 | Zero amount | `"0"` | ValueError raised | ValueError raised | PASS |
| AV-05 | Negative amount | `"-50"` | ValueError raised | ValueError raised | PASS |
| AV-06 | Text input | `"abc"` | ValueError raised | ValueError raised | PASS |
| AV-07 | Empty string | `""` | ValueError raised | ValueError raised | PASS |
| AV-08 | Whitespace only | `"  "` | ValueError raised | ValueError raised | PASS |
| AV-09 | Scientific notation | `"1e2"` | Returns `100.0` | `100.0` | PASS |

---

## Section 2 — Date Validation (8 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| DV-01 | Valid date | `"2026-09-25"` | datetime object returned | datetime object returned | PASS |
| DV-02 | Leap year valid | `"2026-02-28"` | datetime object returned | datetime object returned | PASS |
| DV-03 | Wrong format DD-MM-YYYY | `"25-09-2026"` | ValueError raised | ValueError raised | PASS |
| DV-04 | Slash format | `"2026/09/25"` | ValueError raised | ValueError raised | PASS |
| DV-05 | Impossible date (Feb 30) | `"2026-02-30"` | ValueError raised | ValueError raised | PASS |
| DV-06 | Invalid month (13) | `"2026-13-01"` | ValueError raised | ValueError raised | PASS |
| DV-07 | Empty string | `""` | ValueError raised | ValueError raised | PASS |
| DV-08 | Alphabetic string | `"abcd-ef-gh"` | ValueError raised | ValueError raised | PASS |

---

## Section 3 — ID Generation (3 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| ID-01 | Empty list | `[]` | Returns `1` | `1` | PASS |
| ID-02 | List with 7 records (IDs 1-7) | SAMPLE list | Returns `8` | `8` | PASS |
| ID-03 | List with gaps in IDs (3,7,2) | `[{id:3},{id:7},{id:2}]` | Returns `8` (max+1) | `8` | PASS |

---

## Section 4 — Category List (8 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| CA-01 | List is non-empty | `CATEGORIES` | len > 0 | len = 8 | PASS |
| CA-02 | At least 8 categories | `CATEGORIES` | len >= 8 | len = 8 | PASS |
| CA-03 | Food present | `CATEGORIES` | Contains "Food" | True | PASS |
| CA-04 | Transport present | `CATEGORIES` | Contains "Transport" | True | PASS |
| CA-05 | Entertainment present | `CATEGORIES` | Contains "Entertainment" | True | PASS |
| CA-06 | Health present | `CATEGORIES` | Contains "Health" | True | PASS |
| CA-07 | Bills present | `CATEGORIES` | Contains "Bills" | True | PASS |
| CA-08 | Other present | `CATEGORIES` | Contains "Other" | True | PASS |

---

## Section 5 — View Expenses (2 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| VE-01 | Empty expense list | `[]` | Prints "No expenses" message, no error | "No expenses recorded yet." printed | PASS |
| VE-02 | 7 sample expenses | SAMPLE | Table printed with total 5519.50 | Table printed, total 5519.50 | PASS |

---

## Section 6 — CSV Save & Load (14 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| CS-01 | save_expenses returns True | SAMPLE (7 records) | Returns True | True | PASS |
| CS-02 | CSV file exists after save | — | File exists on disk | File found | PASS |
| CS-03 | CSV has 7 data rows | expenses.csv | 7 rows (excl. header) | 7 rows | PASS |
| CS-04 | CSV has 'id' column | expenses.csv header | "id" present | Present | PASS |
| CS-05 | CSV has 'date' column | expenses.csv header | "date" present | Present | PASS |
| CS-06 | CSV has 'category' column | expenses.csv header | "category" present | Present | PASS |
| CS-07 | CSV has 'amount' column | expenses.csv header | "amount" present | Present | PASS |
| CS-08 | CSV has 'description' column | expenses.csv header | "description" present | Present | PASS |
| CS-09 | load_expenses returns 7 records | expenses.csv | 7 dicts in list | 7 dicts | PASS |
| CS-10 | IDs loaded as int | loaded list | All ids are int | All int | PASS |
| CS-11 | Amounts loaded as float | loaded list | All amounts are float | All float | PASS |
| CS-12 | Categories preserved | loaded list | Same order as SAMPLE | Matches | PASS |
| CS-13 | Amount 1500.00 preserved | loaded list | 1500.00 in amounts | Found | PASS |

---

## Section 7 — Edge Cases: Empty / Missing CSV (3 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| EC-01 | Load from missing file | No expenses.csv | Returns `[]` | `[]` | PASS |
| EC-02 | Load from header-only CSV | CSV with only header row | Returns `[]` | `[]` | PASS |
| EC-03 | Malformed rows skipped | 2 bad rows + 1 good row | 2 warnings, 1 record loaded | 2 warnings printed, 1 record returned | PASS |

---

## Section 8 — Report Generation & Analytics (13 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| RP-01 | Report on empty list | `[]` | "No expenses" message, no crash | Message printed | PASS |
| RP-02 | Report on 7 records | SAMPLE | Full report printed, no crash | Report printed | PASS |
| RP-03 | Grand total | SAMPLE | 5519.50 | 5519.50 | PASS |
| RP-04 | Average | SAMPLE (7 records) | 788.50 | 788.50 | PASS |
| RP-05 | Highest expense | SAMPLE | 2000.00 (Shopping) | 2000.00 | PASS |
| RP-06 | Lowest expense | SAMPLE | 120.50 (Transport) | 120.50 | PASS |
| RP-07 | Food category total | SAMPLE | 600.00 (records 1+5) | 600.00 | PASS |
| RP-08 | Bills category total | SAMPLE | 1500.00 (record 4) | 1500.00 | PASS |
| RP-09 | September 2026 total | SAMPLE | 3050.00 | 3050.00 | PASS |
| RP-10 | August 2026 total | SAMPLE | 1999.00 | 1999.00 | PASS |
| RP-11 | No divide-by-zero (1 record) | `[SAMPLE[0]]` | No ZeroDivisionError | No error | PASS |
| RP-12 | Category percentages sum to 100 | SAMPLE | All pct sum ~100% | Verified | PASS |
| RP-13 | Monthly percentages sum to 100 | SAMPLE | All pct sum ~100% | Verified | PASS |

---

## Section 9 — Visualization (7 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| VZ-01 | ASCII chart on empty list | `[]` | "No data" message, no crash | Message printed | PASS |
| VZ-02 | ASCII chart on 7 records | SAMPLE | Bar chart printed, no crash | Chart printed | PASS |
| VZ-03 | generate_all_charts empty | `[]` | No crash, no files overwritten | Ran without error | PASS |
| VZ-04 | generate_all_charts on data | SAMPLE | 3 PNG files saved | 3 PNGs created | PASS |
| VZ-05 | chart_category_pie.png created | — | File exists | File found on disk | PASS |
| VZ-06 | chart_monthly_bar.png created | — | File exists | File found on disk | PASS |
| VZ-07 | chart_top_expenses.png created | — | File exists | File found on disk | PASS |

---

## Section 10 — Data Persistence (4 tests)

| ID | Scenario | Input | Expected Result | Actual Result | Status |
|----|----------|-------|----------------|---------------|--------|
| PE-01 | Reload count matches | Save 7 → reload | 7 records loaded | 7 records | PASS |
| PE-02 | Total preserved after reload | Save total 5519.50 → reload | Sum = 5519.50 | 5519.50 | PASS |
| PE-03 | Categories preserved after reload | Save SAMPLE → reload | Same categories | Matched | PASS |
| PE-04 | Descriptions preserved | Save SAMPLE → reload | Same descriptions | Matched | PASS |

---

## Summary

| Section | Tests | Passed | Failed |
|---------|-------|--------|--------|
| Amount Validation | 9 | 9 | 0 |
| Date Validation | 8 | 8 | 0 |
| ID Generation | 3 | 3 | 0 |
| Category List | 8 | 8 | 0 |
| View Expenses | 2 | 2 | 0 |
| CSV Save & Load | 13 | 13 | 0 |
| Edge Cases | 3 | 3 | 0 |
| Reports & Analytics | 13 | 13 | 0 |
| Visualization | 7 | 7 | 0 |
| Persistence | 4 | 4 | 0 |
| **TOTAL** | **68** | **68** | **0** |

**Result: ALL TESTS PASSED**
