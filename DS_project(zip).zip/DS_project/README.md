# Personal Expense Tracker

## Project Overview

The **Personal Expense Tracker** is a command-line Python application that helps individuals record, categorise, analyse, and visualise their daily spending. All data is stored persistently in a local CSV file, and the application generates rich statistical reports and Matplotlib charts on demand.

---

## Problem Statement

Managing personal finances manually — on paper or in generic spreadsheets — is tedious, error-prone, and provides no immediate insight into spending patterns. A dedicated, easy-to-use tracker that runs entirely on a student's laptop (no internet, no database server, no paid tools) addresses this gap.

---

## Objectives

1. Allow the user to add, view, and delete expense records quickly.
2. Persist data reliably across application restarts using CSV files.
3. Categorise expenses and compute per-category totals.
4. Produce clear textual reports including average, highest, and lowest spend.
5. Generate publication-quality Matplotlib charts (pie chart, bar charts).
6. Handle invalid user input gracefully without crashing.

---

## Features

| # | Feature | Details |
|---|---------|---------|
| 1 | **Add Expense** | Collects date, category, amount, description with full validation |
| 2 | **View All Expenses** | Formatted table with running total |
| 3 | **Delete Expense** | Remove by ID; confirms before deleting |
| 4 | **Text Report** | Grand total, average, highest, lowest, category breakdown, monthly summary |
| 5 | **ASCII Quick Chart** | Horizontal bar chart in terminal — no dependencies required |
| 6 | **Matplotlib Charts** | Pie chart (category), bar chart (monthly trend), horizontal bar (top expenses) saved as PNG |
| 7 | **CSV Persistence** | Auto-load on startup, explicit save, auto-save on exit |
| 8 | **Input Validation** | Amount (numeric, > 0), date (YYYY-MM-DD), category (non-empty), menu choice |
| 9 | **Error Handling** | try-except for I/O errors, malformed CSV rows, invalid inputs |

---

## Technologies Used

| Technology | Purpose |
|-----------|---------|
| Python 3.10+ | Core language |
| `csv` (stdlib) | Reading and writing expense data |
| `datetime` (stdlib) | Date parsing and formatting |
| `collections.defaultdict` (stdlib) | Aggregation in reports and charts |
| `os` (stdlib) | File path handling |
| `matplotlib 3.7+` | Pie chart, bar charts (saved as PNG) |

---

## Requirements

- Python 3.10 or later
- matplotlib (for PNG chart generation)

---

## Installation

```bash
# 1. Clone or download the project folder
cd DS_project

# 2. Install the dependencies
pip install -r requirements.txt
```

---

## How to Run

To run the modern web-based dashboard application:
```bash
python api.py
```
This will start the FastAPI backend server on `http://127.0.0.1:8000`. 
Open this URL in any modern web browser to access the application.

Alternatively, you can still run the legacy command-line interface:
```bash
python main.py
```


---

## How to Use Each Feature

### 1 — Add Expense
- Press **1** at the main menu.
- Enter a date in `YYYY-MM-DD` format (press Enter to use today's date).
- Choose a category by number or type a custom name.
- Enter the amount (must be a number greater than zero).
- Optionally add a description.

### 2 — View All Expenses
- Press **2**.
- All recorded expenses are shown in a table with a grand total.

### 3 — Generate Report
- Press **3**.
- Displays: grand total, count, average, highest expense, lowest expense, per-category breakdown with percentages, and monthly summary.

### 4 — Quick ASCII Chart
- Press **4**.
- Shows a horizontal ASCII bar chart of spending by category directly in the terminal.

### 5 — Generate Matplotlib Charts (PNG)
- Press **5**.
- Generates three PNG images in the project folder:
  - `chart_category_pie.png` — pie chart by category
  - `chart_monthly_bar.png` — bar chart by month
  - `chart_top_expenses.png` — top 10 individual expenses

### 6 — Delete an Expense
- Press **6**.
- Shows the expense table; enter the ID of the record to delete.

### 7 — Save Data
- Press **7** to save at any time.
- Data is also saved automatically when you exit with **8**.

### 8 — Exit
- Press **8**. Data is auto-saved before closing.

---

## Project Structure

```
DS_project/
├── api.py                     # Modern FastAPI backend and web server
├── static/                    # Frontend web assets
│   ├── index.html             # Modern Vue 3 dashboard UI
│   ├── app.js                 # Frontend application logic
│   └── styles.css             # Tailwind custom styling
├── main.py                    # Legacy CLI entry point
├── expense_manager.py         # Add, view, delete, validate
├── file_handler.py            # CSV load and save
├── reports.py                 # Text analytics and reports
├── visualization.py           # Matplotlib charts + ASCII fallback
├── expenses.csv               # Auto-created on first save
├── test_runner.py             # Automated test suite (68 tests)
├── requirements.txt           # External packages
├── README.md                  # This file
├── PROJECT_DOCUMENTATION.md   # College project documentation
└── TEST_REPORT.md             # Formal test case report
```

---

## Sample Output

```
+------------------------------------------------+
|        Personal Expense Tracker  v2.0         |
|        Track. Analyse. Visualise.             |
+------------------------------------------------+

  [OK] Loaded 7 existing expense(s) from file.

  +------------------------------------+
  |            MAIN MENU              |
  +------------------------------------+
  |  1.  Add Expense                  |
  |  2.  View All Expenses            |
  |  3.  Generate Report              |
  |  4.  Quick ASCII Chart            |
  |  5.  Generate Matplotlib Charts   |
  |  6.  Delete an Expense            |
  |  7.  Save Data                    |
  |  8.  Exit                         |
  +------------------------------------+

  ID    Date         Category               Amount Description
  -------------------------------------------------------------------------------
  1     2026-07-05   Food                   350.00 Lunch
  2     2026-07-20   Transport              120.50 Cab
  ...
  TOTAL                                    5519.50

  Total Expenses        : Rs.   5,519.50
  Average per Expense   : Rs.     788.50
  Highest Expense       : Rs.   2,000.00  (Shopping on 2026-09-25)
  Lowest Expense        : Rs.     120.50  (Transport on 2026-07-20)
```

---

## Visualization Description

Three Matplotlib charts are generated (option 5) and saved as PNG files:

1. **Pie Chart (`chart_category_pie.png`)** — Shows the percentage share of each spending category. The title, labels, and a total summary are included.

2. **Monthly Bar Chart (`chart_monthly_bar.png`)** — Shows total spending per month in chronological order. Each bar is labelled with its Rs. value.

3. **Top Expenses Chart (`chart_top_expenses.png`)** — Horizontal bar chart of up to the 10 largest individual expenses, labelled with category, date, and amount.

All charts use real expense data from `expenses.csv` and handle no-data conditions gracefully.

---

## Limitations

- No edit functionality (only add and delete).
- No multi-user support.
- CSV storage is plain-text (no encryption).
- Charts are saved as files; not rendered interactively in the terminal.
- No budget/target limit feature.

---

## Future Enhancements

- Edit existing expenses.
- Filter and search by date range or category.
- Set monthly budget limits with over-budget warnings.
- Interactive chart display (matplotlib GUI backend).
- Export reports to PDF.
- SQLite database backend for larger datasets.
