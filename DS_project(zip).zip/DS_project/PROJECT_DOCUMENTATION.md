# PROJECT DOCUMENTATION

## Personal Expense Tracker
**Course**: Data Structures / Python Programming  
**Submission Type**: Minor Project  
**Language**: Python 3  

---

## Abstract

The Personal Expense Tracker is a command-line application built in Python that enables users to record, categorise, analyse, and visualise personal financial expenditures. The system reads and writes data using Python's built-in `csv` module, implements structured analytics using lists and dictionaries, generates visual reports with Matplotlib, and enforces robust input validation through exception handling. The project demonstrates practical application of core Python programming concepts in a real-world context.

---

## 1. Introduction

Tracking personal expenses is a fundamental financial habit that helps individuals understand where their money goes, identify unnecessary spending, and plan for the future. While many complex applications exist for this purpose, they often require internet access, account creation, or paid subscriptions.

This project presents a self-contained, offline Python application that can be run by any student with Python installed — no database server, no web server, and no paid tools are required.

---

## 2. Problem Statement

Students and young professionals frequently overspend due to a lack of structured expense tracking. Existing tools are either too complex, platform-dependent, or privacy-invasive. A lightweight, local, command-line tracker that persists data and produces useful analytics addresses this gap effectively.

---

## 3. Objectives

1. Provide a simple, menu-driven interface for recording expenses.
2. Store expense data persistently in a CSV file readable by any spreadsheet application.
3. Support standard expense categories and allow custom categories.
4. Compute meaningful analytics: total, average, highest, lowest, per-category and per-month breakdown.
5. Generate Matplotlib charts (pie, bar) saved as PNG image files.
6. Handle all invalid inputs gracefully without crashing.
7. Maintain clean, modular, beginner-readable Python code.

---

## 4. Existing System

Most available solutions fall into one of these categories:

| Type | Example | Limitation |
|------|---------|-----------|
| Spreadsheet | Microsoft Excel | Manual, no automation |
| Mobile App | Walnut, Money Manager | Requires smartphone, internet |
| Web Application | Mint, YNAB | Account required, privacy concerns |
| Python Scripts | One-file trackers | Not modular, no charts, no persistence |

None of these are suitable as a beginner-level Python learning project that demonstrates core language concepts.

---

## 5. Proposed System

A modular Python CLI application with:
- Menu-driven navigation
- Persistent CSV storage
- Validated data entry
- Statistical reporting
- Matplotlib chart generation
- Separate modules for each responsibility

---

## 6. Functional Requirements

| ID | Requirement |
|----|------------|
| FR-01 | User can add an expense with date, category, amount, and description |
| FR-02 | User can view all expenses in a formatted table |
| FR-03 | User can delete an expense by its ID |
| FR-04 | User can generate a text report with totals, averages, and breakdowns |
| FR-05 | User can generate Matplotlib PNG charts |
| FR-06 | All data persists in expenses.csv across restarts |
| FR-07 | Invalid amounts (non-numeric, zero, negative) are rejected with a message |
| FR-08 | Invalid dates (wrong format, impossible dates) are rejected with a message |
| FR-09 | Invalid menu choices are caught and reported |
| FR-10 | Malformed CSV rows are skipped without crashing |

---

## 7. Technologies Used

| Technology | Version | Role |
|-----------|---------|------|
| Python | 3.10+ | Core language |
| csv (stdlib) | — | Data persistence |
| datetime (stdlib) | — | Date parsing and validation |
| collections (stdlib) | — | defaultdict for aggregation |
| os (stdlib) | — | File path resolution |
| matplotlib | 3.7+ | Chart generation (PNG) |

---

## 8. System Architecture

```
User (Terminal)
      |
      v
  main.py  (Menu Loop + Routing)
      |
      +-----> expense_manager.py  (Add / View / Delete / Validate)
      |
      +-----> file_handler.py     (CSV Load / Save)
      |
      +-----> reports.py          (Text Analytics)
      |
      +-----> visualization.py    (ASCII Chart + Matplotlib PNGs)
                    |
                    v
            expenses.csv   (Persistent Storage)
            chart_*.png    (Generated Charts)
```

### Flow Description

1. The user launches `main.py`.
2. `file_handler.load_expenses()` reads `expenses.csv` into a Python list of dictionaries.
3. The user selects an action from the menu.
4. `expense_manager` handles add/view/delete with full validation.
5. `reports` aggregates data using loops and defaultdict and prints statistics.
6. `visualization` uses matplotlib to generate PNG charts from the live data.
7. Changes are saved by calling `file_handler.save_expenses()`.
8. On exit, data is auto-saved.

---

## 9. Data Structure

Each expense is stored as a Python **dictionary** with five fields:

```python
{
    "id":          int,    # Auto-incremented unique identifier
    "date":        str,    # "YYYY-MM-DD" (e.g. "2026-09-25")
    "category":    str,    # e.g. "Food", "Bills", "Transport"
    "amount":      float,  # Positive number (e.g. 350.00)
    "description": str,    # Optional free text
}
```

All expenses are held in a Python **list** during the session:

```python
expenses = [
    {"id": 1, "date": "2026-08-10", "category": "Food", "amount": 350.0, "description": "Lunch"},
    {"id": 2, "date": "2026-09-01", "category": "Bills", "amount": 1500.0, "description": "Electricity"},
    ...
]
```

The list is loaded from CSV at startup and written back to CSV on save/exit.

---

## 10. Module Descriptions

### `main.py`
Entry point. Defines the banner and menu. Contains the `run()` loop that reads user choices and routes to the appropriate module function. Calls `load_expenses()` on start and `save_expenses()` on exit.

### `expense_manager.py`
- `validate_date(date_str)` — parses YYYY-MM-DD, raises ValueError on failure.
- `validate_amount(amount_str)` — parses float, raises ValueError if ≤ 0 or non-numeric.
- `get_next_id(expenses)` — returns max(id) + 1 for the new record.
- `add_expense(expenses)` — interactive input loop for a new expense.
- `delete_expense(expenses)` — prompt by ID, remove from list.
- `view_expenses(expenses)` — print formatted table with grand total.

### `file_handler.py`
- `load_expenses()` — opens CSV with `csv.DictReader`, casts types, skips malformed rows.
- `save_expenses(expenses)` — writes CSV with `csv.DictWriter`, full overwrite.

### `reports.py`
- `generate_report(expenses)` — orchestrates three sub-functions.
- `_print_summary(expenses)` — total, count, average, highest, lowest.
- `_print_category_breakdown(expenses)` — per-category count, total, percentage.
- `_print_monthly_summary(expenses)` — per-month count, total, percentage.

### `visualization.py`
- `show_category_chart(expenses)` — ASCII horizontal bar chart.
- `show_category_pie_chart(expenses)` — Matplotlib pie chart → PNG.
- `show_monthly_bar_chart(expenses)` — Matplotlib bar chart → PNG.
- `show_top_expenses_chart(expenses)` — Matplotlib horizontal bar → PNG.
- `generate_all_charts(expenses)` — calls all three matplotlib functions.

---

## 11. Algorithm / Processing Flow

### Add Expense
```
START
  Prompt date  -> validate_date()  -> retry on error
  Show categories  -> prompt choice  -> validate non-empty
  Prompt amount  -> validate_amount()  -> retry on error
  Prompt description (optional)
  Build dict {id, date, category, amount, description}
  Append to expenses list
END
```

### Generate Report
```
START
  If expenses is empty -> print message -> return
  Compute grand_total = sum(amounts)
  Compute average = grand_total / len(expenses)
  Find highest = max(amounts), lowest = min(amounts)
  Build cat_totals dict using loop + defaultdict
  Build monthly_totals dict using loop + defaultdict
  Print each section
END
```

### CSV Load
```
START
  If file not found -> return []
  Open file with csv.DictReader
  For each row:
    Try to cast id->int, amount->float
    On error -> print warning, skip row
    On success -> append dict to list
  Return list
END
```

---

## 12. File Handling Approach

- **Format**: Standard CSV (comma-separated values) with header row.
- **Encoding**: UTF-8 for broad compatibility.
- **Location**: Same directory as `main.py` (`expenses.csv`).
- **Load strategy**: Full read on startup.
- **Save strategy**: Full overwrite on every save (appropriate for small datasets).
- **Error handling**: `OSError` caught on both read and write; malformed rows skipped with a warning.

### CSV Structure
```
id,date,category,amount,description
1,2026-08-10,Food,350.00,Lunch with team
2,2026-09-01,Bills,1500.00,Electricity bill
```

---

## 13. Reporting and Analytics Approach

All aggregation is performed in-memory on the Python list using:
- `sum()`, `max()`, `min()` for overall statistics.
- `collections.defaultdict(float)` for category and monthly totals.
- `sorted()` with a `lambda` key for ranked output.
- Division guarded by checking `len(expenses) > 0` before entering report functions.

---

## 14. Visualization Approach

Three charts are generated using **Matplotlib** and saved as PNG files:

1. **Pie Chart** — `ax.pie()` with percentage labels. Annotated with grand total.
2. **Monthly Bar Chart** — `ax.bar()` with value labels on each bar. X-axis shows months in chronological order.
3. **Top Expenses** — `ax.barh()` showing up to 10 largest individual expenses with labels.

All charts use the **Agg** (non-interactive) backend so they work on any machine, including those without a display. Charts are saved via `fig.savefig()` at 150 DPI.

A terminal ASCII chart is also available (option 4) using only the standard library.

---

## 15. Exception Handling

| Location | Exception Handled | Action |
|----------|------------------|--------|
| `validate_amount()` | `ValueError` (non-numeric, ≤ 0, empty) | Raise with message; loop retries |
| `validate_date()` | `ValueError` (wrong format, impossible date) | Raise with message; loop retries |
| `load_expenses()` | `OSError` (file not found, permission) | Print error, return empty list |
| `load_expenses()` each row | `KeyError`, `ValueError` | Print warning, skip row |
| `save_expenses()` | `OSError` | Print error, return False |
| Main menu | Non-numeric / out-of-range | Print error, re-show menu |
| `delete_expense()` | Non-numeric ID, ID not found | Print error, re-prompt |

---

## 16. Testing Methodology

An automated test runner (`test_runner.py`) was written to verify all functional requirements without manual interaction. Tests follow the **Arrange-Act-Assert** pattern and cover:
- Valid inputs accepted correctly.
- Invalid inputs rejected with ValueError.
- CSV round-trip (save then load preserves all data).
- Edge cases: empty list, missing file, header-only file, malformed rows.
- Analytics arithmetic correctness (verified by manual calculation).
- No divide-by-zero on single-record datasets.
- Matplotlib chart files created on disk.

**68 test cases** across 10 sections were executed. All passed.

---

## 17. Test Cases Summary

See `TEST_REPORT.md` for the full table of test cases with inputs, expected results, and status.

---

## 18. Results

| Metric | Value |
|--------|-------|
| Total test cases | 68 |
| Passed | 68 |
| Failed | 0 |
| Lines of code | ~600 (across 5 source files) |
| External packages | 1 (matplotlib) |
| Charts generated | 3 PNG files |
| CSV fields | 5 per record |

---

## 19. Advantages

- Runs offline — no internet or server required.
- Standard CSV output is compatible with Excel and Google Sheets.
- Matplotlib charts are high-resolution PNG files suitable for reports.
- Modular design makes each file independently readable and testable.
- Comprehensive input validation prevents bad data from entering the system.
- Auto-save on exit ensures no data is lost accidentally.

---

## 20. Limitations

- No edit functionality for existing records.
- No search or filter by date range.
- No budget/target setting.
- Data stored as plain text (no encryption).
- Charts saved to file; not rendered interactively.
- Single user only.

---

## 21. Future Enhancements

1. Edit expense records in-place.
2. Filter and search by date range, category, or amount.
3. Monthly budget limits with over-budget alerts.
4. PDF export of reports.
5. SQLite backend for larger data sets.
6. Interactive Matplotlib GUI (switch to TkAgg backend).
7. Web interface using Flask.

---

## 22. Conclusion

The Personal Expense Tracker successfully demonstrates the practical application of core Python programming concepts — lists, dictionaries, functions, loops, conditional logic, exception handling, CSV file I/O, and Matplotlib — in a cohesive, useful, and well-structured application. All 68 automated tests pass, all functional requirements are implemented, and the project is ready for demonstration and submission.
