"""
file_handler.py
---------------
Handles reading from and writing to the CSV file that persists expenses.
Uses Python's built-in csv module as required by the assignment.
"""

import csv
import os

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

CSV_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "expenses.csv")

FIELDNAMES = ["id", "date", "category", "amount", "description"]


# ---------------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------------

def load_expenses():
    """
    Load all expenses from the CSV file into a list of dictionaries.

    Handles:
    - Missing file (first run)
    - Empty file (header-only or truly empty)
    - Malformed rows (skipped with a warning)
    - File I/O errors

    Returns:
        list: A list of expense dictionaries with correct Python types.
    """
    expenses = []

    if not os.path.exists(CSV_FILE):
        return expenses          # First run — no file yet, that's fine

    try:
        with open(CSV_FILE, mode="r", newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)

            if reader.fieldnames is None:
                # Completely empty file
                return expenses

            for row_num, row in enumerate(reader, start=2):
                try:
                    expense = {
                        "id":          int(row["id"]),
                        "date":        row["date"].strip(),
                        "category":    row["category"].strip(),
                        "amount":      float(row["amount"]),
                        "description": row.get("description", "").strip(),
                    }
                    expenses.append(expense)
                except (KeyError, ValueError) as exc:
                    print(f"  [Warning] Skipping malformed row {row_num}: {exc}")

    except OSError as exc:
        print(f"  [Error] Could not read '{CSV_FILE}': {exc}")

    return expenses


# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------

def save_expenses(expenses):
    """
    Persist the in-memory expense list to the CSV file (full overwrite).

    Args:
        expenses (list): List of expense dicts to write.

    Returns:
        bool: True if saved successfully, False on error.
    """
    try:
        with open(CSV_FILE, mode="w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()
            for exp in expenses:
                writer.writerow({
                    "id":          exp["id"],
                    "date":        exp["date"],
                    "category":    exp["category"],
                    "amount":      f"{exp['amount']:.2f}",
                    "description": exp.get("description", ""),
                })
        print(f"  [OK] {len(expenses)} expense(s) saved to '{os.path.basename(CSV_FILE)}'.")
        return True

    except OSError as exc:
        print(f"  [Error] Could not save to '{CSV_FILE}': {exc}")
        return False
