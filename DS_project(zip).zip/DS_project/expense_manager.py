"""
expense_manager.py
------------------
Core business logic for the Personal Expense Tracker.
Handles adding, viewing, deleting, filtering, and validating expenses.
"""

from datetime import datetime

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CATEGORIES = [
    "Food",
    "Transport",
    "Entertainment",
    "Shopping",
    "Education",
    "Bills",
    "Health",
    "Other",
]

DATE_FORMAT = "%Y-%m-%d"  # YYYY-MM-DD used consistently throughout the app


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------

def validate_date(date_str):
    """
    Parse a date string in YYYY-MM-DD format.

    Returns:
        datetime object if valid.

    Raises:
        ValueError: if the format is wrong or the date is impossible.
    """
    return datetime.strptime(date_str.strip(), DATE_FORMAT)


def validate_amount(amount_str):
    """
    Parse and validate an expense amount string.

    Returns:
        float greater than zero.

    Raises:
        ValueError: if the value is not numeric or not > 0.
    """
    if not amount_str.strip():
        raise ValueError("Amount cannot be empty.")
    amount = float(amount_str.strip())
    if amount <= 0:
        raise ValueError("Amount must be greater than zero.")
    return amount


# ---------------------------------------------------------------------------
# ID helper
# ---------------------------------------------------------------------------

def get_next_id(expenses):
    """Return the next available integer ID (max existing ID + 1)."""
    if not expenses:
        return 1
    return max(exp["id"] for exp in expenses) + 1


# ---------------------------------------------------------------------------
# Core CRUD operations
# ---------------------------------------------------------------------------

def add_expense(expenses):
    """
    Interactively collect expense details from the user and append to the list.

    Args:
        expenses (list): Current in-memory list of expense dicts.

    Returns:
        dict: The newly added expense record.
    """
    print("\n--- Add New Expense ---")

    # ── Date ──────────────────────────────────────────────────────────────
    today_str = datetime.today().strftime(DATE_FORMAT)
    while True:
        date_input = input(
            f"  Date (YYYY-MM-DD) [press Enter for today {today_str}]: "
        ).strip()
        if date_input == "":
            date_input = today_str
        try:
            validate_date(date_input)
            break
        except ValueError:
            print("  [Error] Invalid date. Use YYYY-MM-DD (e.g. 2026-09-25).")

    # ── Category ──────────────────────────────────────────────────────────
    print("\n  Available categories:")
    for idx, cat in enumerate(CATEGORIES, start=1):
        print(f"    {idx}. {cat}")

    while True:
        cat_input = input(
            "  Choose category number (or type a custom name): "
        ).strip()
        if cat_input == "":
            print("  [Error] Category cannot be empty.")
            continue
        if cat_input.isdigit():
            cat_idx = int(cat_input) - 1
            if 0 <= cat_idx < len(CATEGORIES):
                category = CATEGORIES[cat_idx]
                break
            else:
                print(f"  [Error] Enter a number between 1 and {len(CATEGORIES)}.")
        else:
            category = cat_input.title()
            break

    # ── Amount ────────────────────────────────────────────────────────────
    while True:
        amount_input = input("  Amount (e.g. 250.50): ").strip()
        try:
            amount = validate_amount(amount_input)
            break
        except ValueError as exc:
            print(f"  [Error] {exc}")

    # ── Description (optional) ────────────────────────────────────────────
    description = input("  Description (optional — press Enter to skip): ").strip()

    expense = {
        "id":          get_next_id(expenses),
        "date":        date_input,
        "category":    category,
        "amount":      amount,
        "description": description,
    }

    expenses.append(expense)
    print(f"\n  [OK] Expense added successfully! (ID: {expense['id']})")
    return expense


def delete_expense(expenses):
    """
    Prompt the user to delete an expense by its ID.

    Args:
        expenses (list): Current in-memory list of expense dicts.
    """
    if not expenses:
        print("\n  No expenses to delete.")
        return

    view_expenses(expenses)

    while True:
        raw = input("  Enter the ID of the expense to delete (or 0 to cancel): ").strip()
        if not raw.isdigit():
            print("  [Error] Please enter a valid numeric ID.")
            continue
        target_id = int(raw)
        if target_id == 0:
            print("  Deletion cancelled.")
            return
        # Find the matching record
        match = next((e for e in expenses if e["id"] == target_id), None)
        if match is None:
            print(f"  [Error] No expense found with ID {target_id}.")
            continue
        expenses.remove(match)
        print(f"  [OK] Expense ID {target_id} deleted.")
        return


# ---------------------------------------------------------------------------
# View / display
# ---------------------------------------------------------------------------

def view_expenses(expenses):
    """
    Display all expenses in a formatted table with a grand total.

    Args:
        expenses (list): List of expense dicts to display.
    """
    print("\n--- All Expenses ---")

    if not expenses:
        print("  No expenses recorded yet.\n")
        return

    col_id   = 5
    col_date = 12
    col_cat  = 16
    col_amt  = 12
    col_desc = 30

    header = (
        f"{'ID':<{col_id}} "
        f"{'Date':<{col_date}} "
        f"{'Category':<{col_cat}} "
        f"{'Amount':>{col_amt}} "
        f"{'Description':<{col_desc}}"
    )
    separator = "-" * len(header)

    print(f"\n  {header}")
    print(f"  {separator}")

    grand_total = 0.0
    for exp in expenses:
        desc = str(exp.get("description", ""))[:col_desc]
        line = (
            f"{exp['id']:<{col_id}} "
            f"{exp['date']:<{col_date}} "
            f"{exp['category']:<{col_cat}} "
            f"{exp['amount']:>{col_amt}.2f} "
            f"{desc:<{col_desc}}"
        )
        print(f"  {line}")
        grand_total += exp["amount"]

    print(f"  {separator}")
    padding = col_id + col_date + col_cat + 2
    print(f"  {'TOTAL':<{padding}} {grand_total:>{col_amt}.2f}")
    print(f"\n  {len(expenses)} expense(s) found.\n")
