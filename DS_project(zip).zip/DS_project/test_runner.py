"""
test_runner.py
--------------
Comprehensive automated test suite for the Personal Expense Tracker.
Covers all requirement areas: validation, CRUD, CSV persistence,
reports, analytics, charts, and edge cases.

Run with:
    python test_runner.py
"""

import os
import sys
import csv
import shutil

# Force UTF-8 output on Windows
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from expense_manager import (
    validate_amount,
    validate_date,
    get_next_id,
    view_expenses,
    CATEGORIES,
    DATE_FORMAT,
)
from file_handler import load_expenses, save_expenses, CSV_FILE
from reports import generate_report
from visualization import show_category_chart, generate_all_charts

# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

_results = []


def check(label, condition):
    """Record and print a single test result."""
    status = "[PASS]" if condition else "[FAIL]"
    _results.append((status, label))
    print(f"  {status}  {label}")


def section(title):
    print(f"\n{'=' * 62}")
    print(f"  {title}")
    print("=" * 62)


# ---------------------------------------------------------------------------
# Sample test data
# ---------------------------------------------------------------------------

SAMPLE = [
    {"id": 1, "date": "2026-07-05", "category": "Food",          "amount": 350.00, "description": "Lunch"},
    {"id": 2, "date": "2026-07-20", "category": "Transport",     "amount": 120.50, "description": "Cab"},
    {"id": 3, "date": "2026-08-01", "category": "Entertainment", "amount": 499.00, "description": "Netflix"},
    {"id": 4, "date": "2026-08-10", "category": "Bills",         "amount": 1500.00,"description": "Electricity"},
    {"id": 5, "date": "2026-09-20", "category": "Food",          "amount": 250.00, "description": "Groceries"},
    {"id": 6, "date": "2026-09-25", "category": "Health",        "amount": 800.00, "description": "Doctor"},
    {"id": 7, "date": "2026-09-25", "category": "Shopping",      "amount": 2000.00,"description": "Clothes"},
]


# ===========================================================================
# SECTION 1 — Amount Validation
# ===========================================================================
section("SECTION 1: Amount Validation")

def _amt_pass(val):
    try:
        return validate_amount(val)
    except ValueError:
        return None

def _amt_fail(val):
    try:
        validate_amount(val)
        return False
    except ValueError:
        return True

check("Valid '250.50' -> 250.50",              _amt_pass("250.50") == 250.50)
check("Valid '1000'   -> 1000.0",              _amt_pass("1000")   == 1000.0)
check("Valid '0.01'   -> 0.01",                _amt_pass("0.01")   == 0.01)
check("'0'    rejected (not > 0)",             _amt_fail("0"))
check("'-50'  rejected (negative)",            _amt_fail("-50"))
check("'abc'  rejected (non-numeric)",         _amt_fail("abc"))
check("''     rejected (empty)",               _amt_fail(""))
check("'  '   rejected (whitespace only)",     _amt_fail("  "))
check("'1e2'  accepted (scientific notation)", _amt_pass("1e2") == 100.0)


# ===========================================================================
# SECTION 2 — Date Validation
# ===========================================================================
section("SECTION 2: Date Validation")

def _date_pass(val):
    try:
        return validate_date(val)
    except ValueError:
        return None

def _date_fail(val):
    try:
        validate_date(val)
        return False
    except ValueError:
        return True

check("'2026-09-25' accepted",           _date_pass("2026-09-25") is not None)
check("'2026-02-28' accepted (valid)",   _date_pass("2026-02-28") is not None)
check("'25-09-2026' rejected (DD-MM-YYYY)", _date_fail("25-09-2026"))
check("'2026/09/25' rejected",           _date_fail("2026/09/25"))
check("'2026-02-30' rejected (impossible)", _date_fail("2026-02-30"))
check("'2026-13-01' rejected (bad month)",  _date_fail("2026-13-01"))
check("''           rejected (empty)",   _date_fail(""))
check("'abcd-ef-gh' rejected",           _date_fail("abcd-ef-gh"))


# ===========================================================================
# SECTION 3 — ID Generation
# ===========================================================================
section("SECTION 3: ID Generation")

check("get_next_id([]) == 1",                            get_next_id([]) == 1)
check("get_next_id(SAMPLE) == 8",                        get_next_id(SAMPLE) == 8)
check("get_next_id with gaps returns max+1",
      get_next_id([{"id": 3}, {"id": 7}, {"id": 2}]) == 8)


# ===========================================================================
# SECTION 4 — Categories
# ===========================================================================
section("SECTION 4: Category List")

check("CATEGORIES is non-empty",         len(CATEGORIES) > 0)
check("At least 8 categories defined",   len(CATEGORIES) >= 8)
check("'Food'          in CATEGORIES",   "Food"          in CATEGORIES)
check("'Transport'     in CATEGORIES",   "Transport"     in CATEGORIES)
check("'Entertainment' in CATEGORIES",   "Entertainment" in CATEGORIES)
check("'Health'        in CATEGORIES",   "Health"        in CATEGORIES)
check("'Bills'         in CATEGORIES",   "Bills"         in CATEGORIES)
check("'Other'         in CATEGORIES",   "Other"         in CATEGORIES)


# ===========================================================================
# SECTION 5 — View Expenses (no exception)
# ===========================================================================
section("SECTION 5: View Expenses")

try:
    view_expenses([])
    check("view_expenses([]) runs without error",           True)
except Exception as e:
    check(f"view_expenses([]) runs without error ({e})",    False)

try:
    view_expenses(SAMPLE)
    check("view_expenses(SAMPLE) runs without error",       True)
except Exception as e:
    check(f"view_expenses(SAMPLE) runs without error ({e})", False)


# ===========================================================================
# SECTION 6 — CSV Save & Load
# ===========================================================================
section("SECTION 6: CSV Save & Load")

backup = CSV_FILE + ".bak"
if os.path.exists(CSV_FILE):
    shutil.copy(CSV_FILE, backup)

# --- Save ---
saved = save_expenses(SAMPLE)
check("save_expenses() returns True",              saved is True)
check("expenses.csv exists after save",            os.path.exists(CSV_FILE))

# Inspect raw CSV
with open(CSV_FILE, newline="", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))
check(f"CSV has {len(SAMPLE)} data rows",          len(rows) == len(SAMPLE))
check("CSV header: 'id'",                          "id"          in rows[0])
check("CSV header: 'date'",                        "date"        in rows[0])
check("CSV header: 'category'",                    "category"    in rows[0])
check("CSV header: 'amount'",                      "amount"      in rows[0])
check("CSV header: 'description'",                 "description" in rows[0])

# --- Load ---
loaded = load_expenses()
check(f"load_expenses() returns {len(SAMPLE)} records",  len(loaded) == len(SAMPLE))
check("IDs loaded as int",                          all(isinstance(e["id"],     int)   for e in loaded))
check("Amounts loaded as float",                    all(isinstance(e["amount"], float) for e in loaded))
check("Categories loaded correctly",
      [e["category"] for e in loaded] == [s["category"] for s in SAMPLE])

# Amount precision
check("Amount 1500.00 preserved",
      any(abs(e["amount"] - 1500.00) < 0.001 for e in loaded))


# ===========================================================================
# SECTION 7 — Empty & Missing CSV edge cases
# ===========================================================================
section("SECTION 7: Edge Cases — Empty / Missing CSV")

# Missing file
temp_csv = CSV_FILE + ".tmp"
if os.path.exists(CSV_FILE):
    shutil.move(CSV_FILE, temp_csv)

result = load_expenses()
check("load_expenses() on missing file returns []",  result == [])

# Empty file (header only)
with open(CSV_FILE, "w", encoding="utf-8") as f:
    f.write("id,date,category,amount,description\n")
result = load_expenses()
check("load_expenses() on header-only CSV returns []", result == [])

# Restore
os.remove(CSV_FILE)
if os.path.exists(temp_csv):
    shutil.move(temp_csv, CSV_FILE)

# Malformed row
malformed_path = CSV_FILE + ".mal"
with open(malformed_path, "w", encoding="utf-8") as f:
    f.write("id,date,category,amount,description\n")
    f.write("BAD_ID,2026-09-25,Food,500.00,OK\n")   # id not int
    f.write("9,2026-09-25,Food,NOT_NUM,Test\n")      # amount not float
    f.write("10,2026-09-25,Health,300.00,Good\n")    # valid row
orig = CSV_FILE
# Temporarily point load to malformed file
import file_handler as _fh
_fh.CSV_FILE = malformed_path
malformed_result = load_expenses()
_fh.CSV_FILE = orig
os.remove(malformed_path)
check("Malformed rows skipped; valid row(s) still loaded",
      len(malformed_result) == 1 and malformed_result[0]["id"] == 10)


# ===========================================================================
# SECTION 8 — Report Generation (analytics)
# ===========================================================================
section("SECTION 8: Report Generation & Analytics")

try:
    generate_report([])
    check("generate_report([]) handles empty list",  True)
except Exception as e:
    check(f"generate_report([]) handles empty list ({e})", False)

try:
    generate_report(SAMPLE)
    check("generate_report(SAMPLE) runs without error", True)
except Exception as e:
    check(f"generate_report(SAMPLE) runs without error ({e})", False)

# Verify arithmetic
amounts     = [s["amount"] for s in SAMPLE]
grand_total = sum(amounts)
check("Grand total == 5519.50",          abs(grand_total - 5519.50) < 0.01)

average = grand_total / len(amounts)
check("Average == 788.50",               abs(average - 788.50) < 0.01)

check("Highest == 2000.00",              max(amounts) == 2000.00)
check("Lowest  == 120.50",               min(amounts) == 120.50)

# Category totals
from collections import defaultdict
cat_totals = defaultdict(float)
for s in SAMPLE:
    cat_totals[s["category"]] += s["amount"]
check("Food total == 600.00",            abs(cat_totals["Food"] - 600.00) < 0.01)
check("Bills total == 1500.00",          abs(cat_totals["Bills"] - 1500.00) < 0.01)

# Monthly totals
monthly = defaultdict(float)
from datetime import datetime
for s in SAMPLE:
    dt = datetime.strptime(s["date"], DATE_FORMAT)
    monthly[dt.strftime("%Y-%m")] += s["amount"]
check("2026-09 total == 3050.00",        abs(monthly["2026-09"] - 3050.00) < 0.01)
check("2026-08 total == 1999.00",        abs(monthly["2026-08"] - 1999.00) < 0.01)

# No divide-by-zero (single record)
try:
    generate_report([SAMPLE[0]])
    check("generate_report([single]) no divide-by-zero", True)
except ZeroDivisionError:
    check("generate_report([single]) no divide-by-zero", False)


# ===========================================================================
# SECTION 9 — Visualization
# ===========================================================================
section("SECTION 9: Visualization")

try:
    show_category_chart([])
    check("show_category_chart([]) — no crash",          True)
except Exception as e:
    check(f"show_category_chart([]) — no crash ({e})",   False)

try:
    show_category_chart(SAMPLE)
    check("show_category_chart(SAMPLE) — no crash",      True)
except Exception as e:
    check(f"show_category_chart(SAMPLE) — no crash ({e})", False)

try:
    generate_all_charts([])
    check("generate_all_charts([]) — no crash on empty", True)
except Exception as e:
    check(f"generate_all_charts([]) — no crash ({e})",   False)

try:
    generate_all_charts(SAMPLE)
    check("generate_all_charts(SAMPLE) — no crash",      True)
except Exception as e:
    check(f"generate_all_charts(SAMPLE) — no crash ({e})", False)

# Verify PNG files were created
for fname in ["chart_category_pie.png", "chart_monthly_bar.png", "chart_top_expenses.png"]:
    fpath = os.path.join(os.path.dirname(os.path.abspath(__file__)), fname)
    check(f"{fname} was created",                         os.path.exists(fpath))


# ===========================================================================
# SECTION 10 — Persistence (Save -> Reload)
# ===========================================================================
section("SECTION 10: Data Persistence (Save -> Reload)")

save_expenses(SAMPLE)
reloaded = load_expenses()

check("Reload count matches",           len(reloaded) == len(SAMPLE))
check("Total preserved after reload",
      abs(sum(e["amount"] for e in reloaded) - sum(s["amount"] for s in SAMPLE)) < 0.01)
check("Categories preserved",
      sorted(e["category"] for e in reloaded) == sorted(s["category"] for s in SAMPLE))
check("Descriptions preserved",
      [e["description"] for e in reloaded] == [s["description"] for s in SAMPLE])

# Restore original backup if it existed
if os.path.exists(backup):
    shutil.move(backup, CSV_FILE)


# ===========================================================================
# FINAL SUMMARY
# ===========================================================================
section("TEST SUMMARY")

passed = sum(1 for s, _ in _results if s == "[PASS]")
failed = sum(1 for s, _ in _results if s == "[FAIL]")
total  = len(_results)

print(f"\n  Passed : {passed} / {total}")
print(f"  Failed : {failed} / {total}")

if failed:
    print("\n  Failed tests:")
    for status, label in _results:
        if status == "[FAIL]":
            print(f"    [FAIL]  {label}")
    sys.exit(1)
else:
    print("\n  All tests passed!\n")
    sys.exit(0)
