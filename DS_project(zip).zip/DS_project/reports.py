"""
reports.py
----------
Generates analytics and summary reports from the stored expenses.

Covers:
  - Grand total, average, highest and lowest single expense
  - Per-category breakdown (count, total, percentage)
  - Monthly summary (count, total, percentage)
"""

from collections import defaultdict
from datetime import datetime
from expense_manager import DATE_FORMAT


# ---------------------------------------------------------------------------
# Public report entry point
# ---------------------------------------------------------------------------

def generate_report(expenses):
    """
    Print a multi-section formatted report to the terminal.

    Sections:
        1. Summary statistics (total, average, highest, lowest)
        2. Category breakdown
        3. Monthly summary

    Args:
        expenses (list): List of expense dictionaries.
    """
    print("\n--- Expense Report ---")

    if not expenses:
        print("  No expenses to report on yet.\n")
        return

    _print_summary(expenses)
    _print_category_breakdown(expenses)
    _print_monthly_summary(expenses)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _print_summary(expenses):
    """Print overall statistics: total, average, highest, lowest expense."""
    amounts     = [exp["amount"] for exp in expenses]
    grand_total = sum(amounts)
    average     = grand_total / len(amounts)          # len is always > 0 here
    highest     = max(amounts)
    lowest      = min(amounts)

    # Find the record for highest and lowest
    highest_exp = next(e for e in expenses if e["amount"] == highest)
    lowest_exp  = next(e for e in expenses if e["amount"] == lowest)

    print(f"\n  {'Total Expenses':<22}: Rs. {grand_total:>10,.2f}")
    print(f"  {'Number of Records':<22}: {len(expenses):>14}")
    print(f"  {'Average per Expense':<22}: Rs. {average:>10,.2f}")
    print(f"  {'Highest Expense':<22}: Rs. {highest:>10,.2f}  "
          f"({highest_exp['category']} on {highest_exp['date']})")
    print(f"  {'Lowest Expense':<22}: Rs. {lowest:>10,.2f}  "
          f"({lowest_exp['category']} on {lowest_exp['date']})")
    print()


def _print_category_breakdown(expenses):
    """Print per-category count, total, and percentage of grand total."""
    grand_total = sum(e["amount"] for e in expenses)

    cat_totals = defaultdict(float)
    cat_counts = defaultdict(int)

    for exp in expenses:
        cat_totals[exp["category"]] += exp["amount"]
        cat_counts[exp["category"]] += 1

    sorted_cats = sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)

    print("  Category Breakdown")
    print("  " + "-" * 64)
    print(f"  {'Category':<20} {'Count':>6} {'Amount (Rs.)':>14} {'% of Total':>12}")
    print("  " + "-" * 64)

    for cat, total in sorted_cats:
        count      = cat_counts[cat]
        pct        = (total / grand_total) * 100   # grand_total > 0 guaranteed
        print(f"  {cat:<20} {count:>6} {total:>14,.2f} {pct:>11.1f}%")

    print("  " + "-" * 64)
    print(f"  {'TOTAL':<20} {len(expenses):>6} {grand_total:>14,.2f} {'100.0%':>12}")
    print()


def _print_monthly_summary(expenses):
    """Print per-month count, total, and percentage of grand total."""
    grand_total = sum(e["amount"] for e in expenses)

    monthly_totals = defaultdict(float)
    monthly_counts = defaultdict(int)

    for exp in expenses:
        try:
            dt        = datetime.strptime(exp["date"], DATE_FORMAT)
            month_key = dt.strftime("%Y-%m")
        except ValueError:
            month_key = "Unknown"

        monthly_totals[month_key] += exp["amount"]
        monthly_counts[month_key] += 1

    # Most recent month first
    sorted_months = sorted(monthly_totals.items(), key=lambda x: x[0], reverse=True)

    print("  Monthly Summary")
    print("  " + "-" * 50)
    print(f"  {'Month':<12} {'Count':>6} {'Amount (Rs.)':>14} {'% of Total':>12}")
    print("  " + "-" * 50)

    for month, total in sorted_months:
        count = monthly_counts[month]
        pct   = (total / grand_total) * 100
        print(f"  {month:<12} {count:>6} {total:>14,.2f} {pct:>11.1f}%")

    print("  " + "-" * 50)
    print(f"  {'TOTAL':<12} {len(expenses):>6} {grand_total:>14,.2f} {'100.0%':>12}\n")
