"""
main.py
-------
Entry point for the Personal Expense Tracker.
Displays the main menu and routes user choices to the appropriate modules.
"""

import sys

# Force UTF-8 output on Windows terminals that default to cp1252
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

from expense_manager import add_expense, view_expenses, delete_expense
from file_handler import load_expenses, save_expenses
from reports import generate_report
from visualization import show_category_chart, generate_all_charts

# ---------------------------------------------------------------------------
# UI constants
# ---------------------------------------------------------------------------

BANNER = """
+------------------------------------------------+
|        Personal Expense Tracker  v2.0         |
|        Track. Analyse. Visualise.             |
+------------------------------------------------+
"""

MENU = """
  +------------------------------------+
  |            MAIN MENU              |
  +------------------------------------+
  |  1.  Add Expense                  |
  |  2.  View All Expenses            |
  |  3.  Generate Report              |
  |  4.  Quick ASCII Chart            |
  |  5.  Generate Matplotlib Charts   |
  |  6.  Delete an Expense            |
  |  7.  Save Data                    |
  |  8.  Exit                         |
  +------------------------------------+
"""

VALID_CHOICES = {"1", "2", "3", "4", "5", "6", "7", "8"}


# ---------------------------------------------------------------------------
# Menu helpers
# ---------------------------------------------------------------------------

def show_menu():
    """Print the main navigation menu."""
    print(MENU)


def get_menu_choice():
    """Prompt the user for a menu choice and return the raw stripped input."""
    return input("  Enter your choice (1-8): ").strip()


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

def run():
    """
    Main application loop.

    On startup:  loads existing expenses from CSV.
    On exit:     auto-saves to CSV.
    """
    print(BANNER)

    expenses = load_expenses()
    if expenses:
        print(f"  [OK] Loaded {len(expenses)} existing expense(s) from file.\n")
    else:
        print("  [Info] No saved expenses found. Starting fresh.\n")

    while True:
        show_menu()
        choice = get_menu_choice()

        if choice not in VALID_CHOICES and choice != "":
            print(
                f"\n  [Error] '{choice}' is not a valid option. "
                f"Please enter a number between 1 and 8.\n"
            )
            continue

        # ── 1. Add Expense ────────────────────────────────────────────
        if choice == "1":
            add_expense(expenses)

        # ── 2. View All Expenses ──────────────────────────────────────
        elif choice == "2":
            view_expenses(expenses)

        # ── 3. Generate Text Report ───────────────────────────────────
        elif choice == "3":
            generate_report(expenses)

        # ── 4. Quick ASCII Chart ──────────────────────────────────────
        elif choice == "4":
            show_category_chart(expenses)

        # ── 5. Matplotlib Charts (PNG) ────────────────────────────────
        elif choice == "5":
            generate_all_charts(expenses)

        # ── 6. Delete an Expense ──────────────────────────────────────
        elif choice == "6":
            delete_expense(expenses)

        # ── 7. Save Data ──────────────────────────────────────────────
        elif choice == "7":
            save_expenses(expenses)

        # ── 8. Exit ───────────────────────────────────────────────────
        elif choice == "8":
            print("\n  Saving data before exit...")
            save_expenses(expenses)
            print("  Goodbye! Thank you for using Personal Expense Tracker.\n")
            break


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    run()
