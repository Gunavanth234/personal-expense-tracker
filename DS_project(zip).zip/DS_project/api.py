from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional

import file_handler
import expense_manager
import os

app = FastAPI(title="Personal Expense Tracker API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/expenses")
def get_expenses():
    expenses = file_handler.load_expenses()
    # Ensure they are sorted by date descending, then id descending
    expenses.sort(key=lambda x: (x["date"], x["id"]), reverse=True)
    return expenses

class ExpenseCreate(BaseModel):
    amount: float
    category: str
    date: str
    description: Optional[str] = ""

@app.post("/api/expenses")
def add_expense(expense: ExpenseCreate):
    expenses = file_handler.load_expenses()
    
    try:
        expense_manager.validate_amount(str(expense.amount))
        expense_manager.validate_date(expense.date)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
        
    if not expense.category:
        raise HTTPException(status_code=400, detail="Category is required.")
        
    new_expense = {
        "id": expense_manager.get_next_id(expenses),
        "date": expense.date,
        "category": expense.category,
        "amount": expense.amount,
        "description": expense.description,
    }
    expenses.append(new_expense)
    file_handler.save_expenses(expenses)
    return new_expense

@app.delete("/api/expenses/{expense_id}")
def delete_expense(expense_id: int):
    expenses = file_handler.load_expenses()
    match = next((e for e in expenses if e["id"] == expense_id), None)
    if not match:
        raise HTTPException(status_code=404, detail="Expense not found")
    expenses.remove(match)
    file_handler.save_expenses(expenses)
    return {"message": "Expense deleted"}

@app.get("/api/analytics")
def get_analytics():
    expenses = file_handler.load_expenses()
    
    amounts = [exp["amount"] for exp in expenses]
    grand_total = sum(amounts) if amounts else 0
    average = grand_total / len(amounts) if amounts else 0
    highest = max(amounts) if amounts else 0
    lowest = min(amounts) if amounts else 0
    
    highest_exp = next((e for e in expenses if e["amount"] == highest), None) if amounts else None
    lowest_exp = next((e for e in expenses if e["amount"] == lowest), None) if amounts else None

    from collections import defaultdict
    cat_totals = defaultdict(float)
    cat_counts = defaultdict(int)
    for exp in expenses:
        cat_totals[exp["category"]] += exp["amount"]
        cat_counts[exp["category"]] += 1
    
    category_breakdown = [
        {"category": cat, "total": total, "count": cat_counts[cat]}
        for cat, total in sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)
    ]

    from datetime import datetime
    monthly_totals = defaultdict(float)
    monthly_counts = defaultdict(int)
    for exp in expenses:
        try:
            dt = datetime.strptime(exp["date"], expense_manager.DATE_FORMAT)
            month_key = dt.strftime("%Y-%m")
        except ValueError:
            month_key = "Unknown"
        monthly_totals[month_key] += exp["amount"]
        monthly_counts[month_key] += 1
        
    monthly_breakdown = [
        {"month": month, "total": total, "count": monthly_counts[month]}
        for month, total in sorted(monthly_totals.items(), key=lambda x: x[0])
    ]
    
    current_month = datetime.now().strftime("%Y-%m")
    current_month_total = monthly_totals.get(current_month, 0)
    
    return {
        "summary": {
            "grand_total": grand_total,
            "average": average,
            "highest": highest,
            "lowest": lowest,
            "count": len(expenses),
            "highest_expense": highest_exp,
            "lowest_expense": lowest_exp,
            "current_month_total": current_month_total
        },
        "category_breakdown": category_breakdown,
        "monthly_breakdown": monthly_breakdown
    }

@app.get("/api/categories")
def get_categories():
    return expense_manager.CATEGORIES

# Serve static frontend files
static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
if not os.path.exists(static_dir):
    os.makedirs(static_dir)

app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/")
def read_index():
    return FileResponse(os.path.join(static_dir, "index.html"))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api:app", host="127.0.0.1", port=8000, reload=True)
